---
layout: documentation
title: Experimental
---

# Experimental

This section contains documentation for Bazel features and workflows that are
considered useful, but have not been fully verified and are not officially
supported.

*  [Converting CocoaPods dependencies](migrate-cocoapods.html)
