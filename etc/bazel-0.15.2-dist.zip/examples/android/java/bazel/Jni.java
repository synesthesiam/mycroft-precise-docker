package bazel;

/**
 * JNI stubs for the Bazel Android "Hello, World" app.
 */
public class Jni {
  public static native String hello();
}
